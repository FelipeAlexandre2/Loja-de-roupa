import React, { useState } from 'react';
import { Search, Plus, Minus, Trash2, ShoppingCart, Banknote, QrCode, CreditCard } from 'lucide-react';
import { fetchWithAuth } from '../utils/fetchWithAuth';

interface ProdutoCart {
  id: number;
  nome: string;
  preco: number;
  quantidade: number;
}

const PDV: React.FC = () => {
  const [carrinho, setCarrinho] = useState<ProdutoCart[]>([]);
  const [busca, setBusca] = useState('');
  const [mensagemExtra, setMensagemExtra] = useState('');
  const [formaPagamento, setFormaPagamento] = useState<'Dinheiro' | 'Pix' | 'Cartão'>('Dinheiro');

  const buscarProdutoPorCodigo = async (codigo: string) => {
    try {
      setMensagemExtra('Buscando...');
      let response = await fetchWithAuth(`${import.meta.env.VITE_API_URL}/api/produtos/barras/${codigo}`);
      
      // Se não achou por código de barra, e for apenas números, tenta achar pelo "Cód." (ID do produto)
      if (!response.ok && !isNaN(Number(codigo))) {
         response = await fetchWithAuth(`${import.meta.env.VITE_API_URL}/api/produtos/${codigo}`);
      }

      if (response.ok) {
        const produto = await response.json();
        setCarrinho(prev => {
          const itemExistente = prev.find(i => i.id === produto.id);
          if (itemExistente) {
            return prev.map(i => i.id === produto.id ? { ...i, quantidade: i.quantidade + 1 } : i);
          }
          return [...prev, { id: produto.id, nome: produto.nome, preco: produto.preco, quantidade: 1 }];
        });
        setMensagemExtra(`Produto adicionado: ${produto.nome}`);
        setBusca('');
      } else {
        setMensagemExtra('Produto não encontrado! Tente o Cód. (ex: 1) ou Código de Barras.');
      }
    } catch (err) {
      setMensagemExtra('Erro ao conectar com a API.');
    }
  };

  const handleFinalizarVenda = async () => {
    if (carrinho.length === 0) {
      alert('O carrinho está vazio!');
      return;
    }

    try {
      setMensagemExtra('Finalizando venda...');
      const itensVenda = carrinho.map(item => ({
        produto: { id: item.id },
        quantidade: item.quantidade
      }));

      const response = await fetchWithAuth(`${import.meta.env.VITE_API_URL}/api/vendas`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ itens: itensVenda, formaPagamento })
      });

      if (response.ok) {
        setCarrinho([]);
        setFormaPagamento('Dinheiro');
        setMensagemExtra('Venda finalizada com sucesso!');
        setTimeout(() => setMensagemExtra(''), 3000);
      } else {
        const errorData = await response.json();
        setMensagemExtra('Erro: ' + (errorData.message || 'Falha ao registrar venda. Verifique o estoque.'));
      }
    } catch (err) {
      setMensagemExtra('Erro de conexão ao finalizar a venda.');
    }
  };

  const alterarQuantidade = (id: number, delta: number) => {
    setCarrinho(prev => prev.map(item => {
      if (item.id === id) {
        const novaQtd = Math.max(1, item.quantidade + delta);
        return { ...item, quantidade: novaQtd };
      }
      return item;
    }));
  };

  const removerDoCarrinho = (id: number) => {
    setCarrinho(prev => prev.filter(item => item.id !== id));
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && busca.trim() !== '') {
      buscarProdutoPorCodigo(busca.trim());
    }
  };

  const total = carrinho.reduce((acc, item) => acc + (item.preco * item.quantidade), 0);

  return (
    <div style={{ height: 'calc(100vh - 120px)', display: 'flex', gap: '1.5rem' }}>
      
      {/* Esquerda: Produtos */}
      <div style={{ flex: '2', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <h1 style={{ margin: 0, color: 'var(--color-navy)', fontSize: '1.5rem' }}>Frente de Caixa (PDV)</h1>
        
        <div style={{ position: 'relative' }}>
          <Search size={20} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--color-text-muted)' }} />
          <input 
            type="text" 
            className="input" 
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Passe o leitor de código de barras ou digite o código..." 
            style={{ paddingLeft: '3rem', padding: '1rem 1rem 1rem 3rem', fontSize: '1.2rem', width: '100%', borderRadius: '8px', border: '2px solid var(--color-navy)' }}
            autoFocus
          />
        </div>

        {/* Mensagens Rápidas */}
        <div style={{ marginTop: '1rem', color: mensagemExtra.includes('não') || mensagemExtra.includes('Erro') ? 'var(--color-red)' : 'green', fontWeight: 'bold' }}>
            {mensagemExtra}
        </div>

        <div className="card" style={{ flex: 1, overflowY: 'auto', padding: '1rem' }}>
          <p style={{ color: 'var(--color-text-muted)', textAlign: 'center', marginTop: '2rem' }}>
            Aguardando leitura de código de barras...
          </p>
        </div>
      </div>

      {/* Direita: Cupom / Carrinho */}
      <div className="card" style={{ flex: '1.2', display: 'flex', flexDirection: 'column', minWidth: '350px' }}>
        <div style={{ padding: '1.5rem', borderBottom: '1px solid var(--color-border)', backgroundColor: 'var(--color-navy)', color: 'white' }}>
          <h2 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <ShoppingCart size={24} />
            Cupom Não Fiscal
          </h2>
        </div>

        {/* Itens do Carrinho */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '1rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {carrinho.map(item => (
            <div key={item.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingBottom: '1rem', borderBottom: '1px dashed var(--color-border)' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, color: 'var(--color-navy)' }}>{item.nome}</div>
                <div style={{ color: 'var(--color-text-muted)', fontSize: '0.875rem' }}>R$ {item.preco.toFixed(2).replace('.', ',')} un.</div>
              </div>
              
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <button onClick={() => alterarQuantidade(item.id, -1)} className="btn btn-outline" style={{ padding: '0.25rem', minWidth: '30px' }}><Minus size={16} /></button>
                <span style={{ fontWeight: 600, width: '20px', textAlign: 'center' }}>{item.quantidade}</span>
                <button onClick={() => alterarQuantidade(item.id, 1)} className="btn btn-outline" style={{ padding: '0.25rem', minWidth: '30px' }}><Plus size={16} /></button>
                <button onClick={() => removerDoCarrinho(item.id)} className="btn btn-outline" style={{ padding: '0.25rem', minWidth: '30px', border: 'none', color: 'var(--color-red)' }} title="Remover"><Trash2 size={16} /></button>
              </div>
            </div>
          ))}
          {carrinho.length === 0 && (
            <div style={{ textAlign: 'center', color: 'var(--color-text-muted)', marginTop: '2rem' }}>
              Carrinho vazio
            </div>
          )}
        </div>

        {/* Resumo e Pagamento */}
        <div style={{ padding: '1.5rem', borderTop: '2px dashed var(--color-border)', backgroundColor: '#FAFAFA' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
            <span style={{ fontSize: '1.25rem', color: 'var(--color-text-muted)' }}>Total:</span>
            <span style={{ fontSize: '2rem', fontWeight: 'bold', color: 'var(--color-navy)' }}>
              R$ {total.toFixed(2).replace('.', ',')}
            </span>
          </div>

          {/* Forma de Pagamento */}
          <div style={{ marginBottom: '1rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500, fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>FORMA DE PAGAMENTO</label>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <button
                type="button"
                onClick={() => setFormaPagamento('Dinheiro')}
                style={{
                  flex: 1, padding: '0.6rem 0.25rem', border: '2px solid',
                  borderColor: formaPagamento === 'Dinheiro' ? '#16a34a' : 'var(--color-border)',
                  backgroundColor: formaPagamento === 'Dinheiro' ? '#f0fdf4' : 'white',
                  borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '0.75rem',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.2rem',
                  color: formaPagamento === 'Dinheiro' ? '#16a34a' : 'var(--color-text-muted)'
                }}
              >
                <Banknote size={18} />
                Dinheiro
              </button>
              <button
                type="button"
                onClick={() => setFormaPagamento('Pix')}
                style={{
                  flex: 1, padding: '0.6rem 0.25rem', border: '2px solid',
                  borderColor: formaPagamento === 'Pix' ? '#7c3aed' : 'var(--color-border)',
                  backgroundColor: formaPagamento === 'Pix' ? '#f5f3ff' : 'white',
                  borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '0.75rem',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.2rem',
                  color: formaPagamento === 'Pix' ? '#7c3aed' : 'var(--color-text-muted)'
                }}
              >
                <QrCode size={18} />
                Pix
              </button>
              <button
                type="button"
                onClick={() => setFormaPagamento('Cartão')}
                style={{
                  flex: 1, padding: '0.6rem 0.25rem', border: '2px solid',
                  borderColor: formaPagamento === 'Cartão' ? '#0369a1' : 'var(--color-border)',
                  backgroundColor: formaPagamento === 'Cartão' ? '#eff6ff' : 'white',
                  borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '0.75rem',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.2rem',
                  color: formaPagamento === 'Cartão' ? '#0369a1' : 'var(--color-text-muted)'
                }}
              >
                <CreditCard size={18} />
                Cartão
              </button>
            </div>
          </div>

          <button onClick={handleFinalizarVenda} className="btn btn-primary" style={{ width: '100%', padding: '1.25rem', fontSize: '1.25rem', opacity: carrinho.length === 0 ? 0.5 : 1 }}>
            Finalizar Venda
          </button>
        </div>
      </div>

    </div>
  );
};

export default PDV;
