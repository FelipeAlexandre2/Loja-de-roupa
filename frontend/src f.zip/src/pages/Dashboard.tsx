import React, { useState, useEffect } from 'react';
import { ShoppingBag, TrendingUp, AlertTriangle, Package, ShoppingCart, Wallet } from 'lucide-react';
import { fetchWithAuth } from '../utils/fetchWithAuth';

interface DashboardResumo {
  vendasHoje: number;
  vendas30Dias: number;
  produtoMaisVendido: string;
  totalPecasEstoque: number;
}

const Dashboard: React.FC = () => {
  const [resumo, setResumo] = useState<DashboardResumo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    carregarResumo();
  }, []);

  const carregarResumo = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetchWithAuth(`${import.meta.env.VITE_API_URL}/api/dashboard`);

      if (!res.ok) {
        throw new Error('Falha ao buscar resumo do backend');
      }

      const data = await res.json();
      setResumo({
        vendasHoje: Number(data.vendasHoje) || 0,
        vendas30Dias: Number(data.vendas30Dias) || 0,
        produtoMaisVendido: data.produtoMaisVendido || 'Nenhum',
        totalPecasEstoque: Number(data.totalPecasEstoque) || 0
      });
    } catch (err: any) {
      console.error(err);
      setError('Não foi possível carregar as informações do painel.');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (val: number) => {
    return `R$ ${val.toFixed(2).replace('.', ',')}`;
  };

  const username = localStorage.getItem('username') || 'Administrador';

  return (
    <div>
      {/* Cabeçalho Aconchegante */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ margin: '0 0 0.5rem 0', color: 'var(--color-navy)', fontSize: '1.8rem' }}>Olá, {username}! 👋</h1>
          <p style={{ margin: 0, color: 'var(--color-text-muted)' }}>Aqui está o resumo financeiro da sua loja e barbearia.</p>
        </div>
        <button className="btn-primary" onClick={carregarResumo} disabled={loading} style={{ alignSelf: 'flex-start' }}>
          {loading ? 'Atualizando...' : 'Atualizar Dados'}
        </button>
      </div>

      {error && (
        <div style={{ color: 'red', marginBottom: '1rem', padding: '1rem', backgroundColor: '#ffeebb', borderRadius: '4px' }}>
          {error}
        </div>
      )}

      {loading && !resumo ? (
        <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--color-text-muted)' }}>
          Carregando suas informações...
        </div>
      ) : (
        <div className="grid grid-cols-4 md:grid-cols-2 sm:grid-cols-1">
          {/* Card Vendas Hoje */}
          <div className="stat-card">
            <div style={{ backgroundColor: '#E8F5E9', padding: '1rem', borderRadius: '50%', color: '#2E7D32' }}>
              <TrendingUp size={24} />
            </div>
            <div>
              <div style={{ color: 'var(--color-text-muted)', fontSize: '0.875rem' }}>Vendas Hoje</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: 'var(--color-navy)' }}>{formatCurrency(resumo?.vendasHoje || 0)}</div>
            </div>
          </div>

          {/* Card Mensal */}
          <div className="stat-card">
            <div style={{ backgroundColor: '#E3F2FD', padding: '1rem', borderRadius: '50%', color: '#1565C0' }}>
              <ShoppingBag size={24} />
            </div>
            <div>
              <div style={{ color: 'var(--color-text-muted)', fontSize: '0.875rem' }}>Últimos 30 Dias</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: 'var(--color-navy)' }}>{formatCurrency(resumo?.vendas30Dias || 0)}</div>
            </div>
          </div>

          {/* Card Produto Destaque */}
          <div className="stat-card">
            <div style={{ backgroundColor: '#FFEBEE', padding: '1rem', borderRadius: '50%', color: '#C62828' }}>
              <AlertTriangle size={24} />
            </div>
            <div>
              <div style={{ color: 'var(--color-text-muted)', fontSize: '0.875rem' }}>Roupa Mais Vendida</div>
              <div style={{ fontSize: '1.1rem', fontWeight: 'bold', color: 'var(--color-navy)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '150px' }} title={resumo?.produtoMaisVendido}>
                {resumo?.produtoMaisVendido}
              </div>
            </div>
          </div>

          {/* Card Total Estoque */}
          <div className="stat-card">
            <div style={{ backgroundColor: '#FFF3E0', padding: '1rem', borderRadius: '50%', color: '#E65100' }}>
              <Package size={24} />
            </div>
            <div>
              <div style={{ color: 'var(--color-text-muted)', fontSize: '0.875rem' }}>Peças no Estoque</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: 'var(--color-navy)' }}>{resumo?.totalPecasEstoque || 0}</div>
            </div>
          </div>
        </div>
      )}

      {/* Ações Rápidas em formato de Bloco/Card */}
      <div style={{ marginTop: '3rem' }}>
        <h2 style={{ color: 'var(--color-navy)', fontSize: '1.25rem', marginBottom: '1.5rem', borderBottom: '1px solid var(--color-border)', paddingBottom: '0.5rem' }}>O que você deseja fazer agora?</h2>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.5rem' }}>

          <a href="/pdv" className="stat-card" style={{ textDecoration: 'none', flexDirection: 'column', padding: '2rem 1rem', textAlign: 'center', justifyContent: 'center' }}>
            <div style={{ backgroundColor: 'rgba(52, 152, 219, 0.1)', padding: '1rem', borderRadius: '50%', color: '#3498db', marginBottom: '0.5rem' }}>
              <ShoppingCart size={36} />
            </div>
            <strong style={{ color: 'var(--color-navy)', fontSize: '1.2rem' }}>Frente de Caixa</strong>
            <span style={{ fontSize: '0.9rem', color: 'var(--color-text-muted)' }}>Registrar uma nova venda</span>
          </a>

          <a href="/caixa" className="stat-card" style={{ textDecoration: 'none', flexDirection: 'column', padding: '2rem 1rem', textAlign: 'center', justifyContent: 'center' }}>
            <div style={{ backgroundColor: 'rgba(46, 204, 113, 0.1)', padding: '1rem', borderRadius: '50%', color: '#27ae60', marginBottom: '0.5rem' }}>
              <Wallet size={36} />
            </div>
            <strong style={{ color: 'var(--color-navy)', fontSize: '1.2rem' }}>Caixa</strong>
            <span style={{ fontSize: '0.9rem', color: 'var(--color-text-muted)' }}>Resumo Financeiro do Dia</span>
          </a>

          <a href="/estoque" className="stat-card" style={{ textDecoration: 'none', flexDirection: 'column', padding: '2rem 1rem', textAlign: 'center', justifyContent: 'center' }}>
            <div style={{ backgroundColor: 'rgba(230, 81, 0, 0.1)', padding: '1rem', borderRadius: '50%', color: '#E65100', marginBottom: '0.5rem' }}>
              <Package size={36} />
            </div>
            <strong style={{ color: 'var(--color-navy)', fontSize: '1.2rem' }}>Meu Estoque</strong>
            <span style={{ fontSize: '0.9rem', color: 'var(--color-text-muted)' }}>Cadastrar Roupa Nova</span>
          </a>

        </div>
      </div>
    </div>
  );
};

export default Dashboard;
