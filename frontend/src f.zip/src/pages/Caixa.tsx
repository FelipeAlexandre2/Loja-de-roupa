import React, { useState, useEffect } from 'react';
import { fetchWithAuth } from '../utils/fetchWithAuth';
import { Wallet, ShoppingCart, Scissors, ArrowDownCircle, ArrowUpCircle } from 'lucide-react';

interface ResumoVendas {
    data?: string;
    quantidadeVendas?: number;
    totalArrecadado?: number;
    totalItensVendidos?: number;
}

interface ResumoBarbearia {
    data?: string;
    totalCortes?: number;
    totalArrecadado?: number;
    jacson?: { quantidade: number; total: number };
    mizael?: { quantidade: number; total: number };
}

interface ResumoMovimentacao {
    data?: string;
    totalSangria?: number;
    totalSuprimento?: number;
}

const CaixaContent: React.FC = () => {
    const [resumoVendas, setResumoVendas] = useState<ResumoVendas | null>(null);
    const [resumoBarbearia, setResumoBarbearia] = useState<ResumoBarbearia | null>(null);
    const [resumoMov, setResumoMov] = useState<ResumoMovimentacao | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    // Modal State
    const [showModal, setShowModal] = useState(false);
    const [tipoMov, setTipoMov] = useState<'SANGRIA' | 'SUPRIMENTO'>('SANGRIA');
    const [valorMov, setValorMov] = useState('');
    const [descMov, setDescMov] = useState('');
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        carregarDados();
    }, []);

    const carregarDados = async () => {
        try {
            setLoading(true);
            setError(null);

            const [vendasRes, barbeariaRes, movRes] = await Promise.all([
                fetchWithAuth(`${import.meta.env.VITE_API_URL}/api/vendas/resumo`),
                fetchWithAuth(`${import.meta.env.VITE_API_URL}/api/barbearia/resumo`),
                fetchWithAuth(`${import.meta.env.VITE_API_URL}/api/caixamovimento/resumo`)
            ]);

            if (!vendasRes.ok || !barbeariaRes.ok || !movRes.ok) {
                throw new Error('Falha na resposta da API');
            }

            const vendasData = await vendasRes.json();
            const barbeariaData = await barbeariaRes.json();
            const movData = await movRes.json();

            setResumoVendas(vendasData);
            setResumoBarbearia(barbeariaData);
            setResumoMov(movData);
        } catch (err: any) {
            console.error('Erro Caixa:', err);
            setError('Falha de conexão. O servidor pode estar reiniciando ou indisponível.');
        } finally {
            setLoading(false);
        }
    };

    const handleSalvarMovimentacao = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!valorMov || isNaN(Number(valorMov.replace(',', '.')))) {
            alert('Por favor, insira um valor numérico válido.');
            return;
        }

        try {
            setSubmitting(true);
            const res = await fetchWithAuth(`${import.meta.env.VITE_API_URL}/api/caixamovimento`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    tipo: tipoMov,
                    valor: Number(valorMov.replace(',', '.')),
                    descricao: descMov
                })
            });

            if (!res.ok) throw new Error('Erro ao salvar movimentação');

            setShowModal(false);
            setValorMov('');
            setDescMov('');
            carregarDados();
        } catch (err) {
            alert('Não foi possível salvar a movimentação. Verifique sua conexão.');
        } finally {
            setSubmitting(false);
        }
    };

    if (loading && !resumoVendas) {
        return (
            <div className="pdv-container">
                <header className="page-header">
                    <h1>Gestão de Caixa</h1>
                </header>
                <div style={{ padding: '2rem', textAlign: 'center' }}>Carregando dados...</div>
            </div>
        );
    }

    const formatCurrency = (val: any) => {
        const num = Number(val) || 0;
        return `R$ ${num.toFixed(2).replace('.', ',')}`;
    };

    const totalVendas = Number(resumoVendas?.totalArrecadado) || 0;
    
    // Fallback: se o backend antigo não mandar na raiz, somamos de dentro dos objetos "jacson" e "mizael"
    const totalBarbearia = Number(resumoBarbearia?.totalArrecadado) || 
        ((resumoBarbearia?.jacson?.total || 0) + (resumoBarbearia?.mizael?.total || 0)) || 0;
        
    const cortesBarbearia = resumoBarbearia?.totalCortes || 
        ((resumoBarbearia?.jacson?.quantidade || 0) + (resumoBarbearia?.mizael?.quantidade || 0)) || 0;

    const totalSuprimento = Number(resumoMov?.totalSuprimento) || 0;
    const totalSangria = Number(resumoMov?.totalSangria) || 0;

    // Matemática Financeira do Caixa
    const totalArrecadado = totalVendas + totalBarbearia;
    const saldoFinal = totalArrecadado + totalSuprimento - totalSangria;

    return (
        <div className="pdv-container">
            <header className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
                <h1 style={{ margin: 0 }}>Gestão de Caixa</h1>
                <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                    <button className="btn" style={{ backgroundColor: '#27ae60', color: 'white' }} onClick={() => { setTipoMov('SUPRIMENTO'); setShowModal(true); }}>
                        <ArrowUpCircle size={18} /> Entrada (Suprimento)
                    </button>
                    <button className="btn" style={{ backgroundColor: '#e74c3c', color: 'white' }} onClick={() => { setTipoMov('SANGRIA'); setShowModal(true); }}>
                        <ArrowDownCircle size={18} /> Retirada (Sangria)
                    </button>
                    <button className="btn-secondary" onClick={carregarDados}>Atualizar</button>
                </div>
            </header>

            {error && (
                <div style={{ color: 'red', marginBottom: '1rem', padding: '1rem', backgroundColor: '#ffeebb', borderRadius: '4px' }}>
                    {error}
                </div>
            )}

            <div className="dashboard-grid" style={{ marginBottom: '2rem' }}>
                {/* Vendas */}
                <div className="stat-card">
                    <div className="stat-icon" style={{ backgroundColor: 'rgba(52, 152, 219, 0.1)', color: '#3498db' }}>
                        <ShoppingCart size={24} />
                    </div>
                    <div className="stat-content">
                        <h3>Vendas Loja (Hoje)</h3>
                        <div className="stat-value">
                            {formatCurrency(totalVendas)}
                        </div>
                        <div className="stat-label">
                            {resumoVendas?.quantidadeVendas || 0} vendas
                        </div>
                    </div>
                </div>

                {/* Barbearia */}
                <div className="stat-card">
                    <div className="stat-icon" style={{ backgroundColor: 'rgba(155, 89, 182, 0.1)', color: '#9b59b6' }}>
                        <Scissors size={24} />
                    </div>
                    <div className="stat-content">
                        <h3>Barbearia (Hoje)</h3>
                        <div className="stat-value">
                            {formatCurrency(totalBarbearia)}
                        </div>
                        <div className="stat-label">
                            {cortesBarbearia} cortes
                        </div>
                    </div>
                </div>

                {/* Entradas Extras */}
                <div className="stat-card">
                    <div className="stat-icon" style={{ backgroundColor: 'rgba(46, 204, 113, 0.1)', color: '#27ae60' }}>
                        <ArrowUpCircle size={24} />
                    </div>
                    <div className="stat-content">
                        <h3>Suprimentos (+ Troco)</h3>
                        <div className="stat-value" style={{ color: '#27ae60' }}>
                            {formatCurrency(totalSuprimento)}
                        </div>
                    </div>
                </div>

                {/* Saidas Extras */}
                <div className="stat-card">
                    <div className="stat-icon" style={{ backgroundColor: 'rgba(231, 76, 60, 0.1)', color: '#e74c3c' }}>
                        <ArrowDownCircle size={24} />
                    </div>
                    <div className="stat-content">
                        <h3>Sangrias (- Retiradas)</h3>
                        <div className="stat-value" style={{ color: '#e74c3c' }}>
                            {formatCurrency(totalSangria)}
                        </div>
                    </div>
                </div>
            </div>

            {/* Total Saldo da Gaveta */}
            <div className="stat-card" style={{ border: '2px solid var(--color-navy)', backgroundColor: '#f8fafc', padding: '2rem' }}>
                <div className="stat-icon" style={{ backgroundColor: 'var(--color-navy)', color: 'white', padding: '1.5rem', width: 'auto', height: 'auto' }}>
                    <Wallet size={36} />
                </div>
                <div className="stat-content" style={{ paddingLeft: '1rem' }}>
                    <h3 style={{ fontSize: '1.2rem', margin: '0 0 0.5rem 0' }}>Saldo Real na Gaveta</h3>
                    <div className="stat-value" style={{ color: 'var(--color-navy)', fontSize: '3rem' }}>
                        {formatCurrency(saldoFinal)}
                    </div>
                    <div className="stat-label" style={{ fontSize: '1rem', marginTop: '0.5rem' }}>
                        (Vendas e Cortes + Suprimentos) - Sangrias
                    </div>
                </div>
            </div>

            {/* Modal de Movimentação */}
            {showModal && (
                <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
                    <div className="card" style={{ width: '100%', maxWidth: '400px', padding: '2rem', animation: 'fadeInUp 0.3s ease-out' }}>
                        <h2 style={{ marginTop: 0, color: tipoMov === 'SANGRIA' ? '#e74c3c' : '#27ae60' }}>
                            {tipoMov === 'SANGRIA' ? 'Retirar Dinheiro (Sangria)' : 'Adicionar Troco (Suprimento)'}
                        </h2>

                        <form onSubmit={handleSalvarMovimentacao} style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginTop: '1.5rem' }}>
                            <div>
                                <label className="form-label" style={{ display: 'block', marginBottom: '0.5rem' }}>Valor (R$):</label>
                                <input
                                    type="text"
                                    className="input"
                                    placeholder="Ex: 50,00"
                                    value={valorMov}
                                    onChange={e => setValorMov(e.target.value)}
                                    required
                                    autoFocus
                                />
                            </div>

                            <div>
                                <label className="form-label" style={{ display: 'block', marginBottom: '0.5rem' }}>Motivo / Descrição:</label>
                                <input
                                    type="text"
                                    className="input"
                                    placeholder={tipoMov === 'SANGRIA' ? 'Ex: Pagamento Fornecedor' : 'Ex: Troco inicial da gaveta'}
                                    value={descMov}
                                    onChange={e => setDescMov(e.target.value)}
                                    required
                                />
                            </div>

                            <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem', justifyContent: 'flex-end' }}>
                                <button type="button" className="btn btn-outline" onClick={() => setShowModal(false)}>Cancelar</button>
                                <button type="submit" className="btn" style={{ backgroundColor: tipoMov === 'SANGRIA' ? '#e74c3c' : '#27ae60', color: 'white' }} disabled={submitting}>
                                    {submitting ? 'Salvando...' : 'Confirmar'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

// Error Boundary
class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean, errorMsg: string }> {
    constructor(props: any) {
        super(props);
        this.state = { hasError: false, errorMsg: '' };
    }
    static getDerivedStateFromError(error: any) {
        return { hasError: true, errorMsg: error.message };
    }
    render() {
        if (this.state.hasError) {
            return (
                <div style={{ padding: '2rem', color: 'red' }}>
                    <h2>Erro Crítico no Caixa</h2>
                    <p>Detalhes: {this.state.errorMsg}</p>
                </div>
            );
        }
        return this.props.children;
    }
}

const Caixa: React.FC = () => (
    <ErrorBoundary>
        <CaixaContent />
    </ErrorBoundary>
);

export default Caixa;
