import React, { useState, useEffect } from 'react';
import { Scissors, DollarSign, User, Banknote, CreditCard, QrCode, CheckCircle, AlertTriangle, X, Trash2 } from 'lucide-react';
import axios from 'axios';

const API_URL = `${import.meta.env.VITE_API_URL}/api/barbearia`;

interface ResumoMensal {
  cortesDia: any[];
  jacson: { quantidade: number; total: number };
  mizael: { quantidade: number; total: number };
}

interface Toast {
  id: number;
  tipo: 'sucesso' | 'erro';
  mensagem: string;
  sub?: string;
}

interface ModalConfirm {
  aberto: boolean;
  corteId: number | null;
  barbeiro: string;
  valor: number;
}

const Barbearia: React.FC = () => {
  const [resumo, setResumo] = useState<ResumoMensal | null>(null);
  const [loading, setLoading] = useState(true);
  const [valorCorte, setValorCorte] = useState<number | string>(35);
  const [barbeiro, setBarbeiro] = useState<'Jacson' | 'Mizael'>('Jacson');
  const [formaPagamento, setFormaPagamento] = useState<'Dinheiro' | 'Pix' | 'Cartão'>('Dinheiro');
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [modal, setModal] = useState<ModalConfirm>({ aberto: false, corteId: null, barbeiro: '', valor: 0 });
  const [lancando, setLancando] = useState(false);

  const showToast = (tipo: 'sucesso' | 'erro', mensagem: string, sub?: string) => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, tipo, mensagem, sub }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 4000);
  };

  const fetchResumo = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API_URL}/resumo`);
      setResumo(response.data);
    } catch (error) {
      console.error('Erro ao buscar resumo da barbearia', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResumo();
  }, []);

  const handleLancar = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!valorCorte || Number(valorCorte) <= 0) return;
    setLancando(true);
    try {
      await axios.post(API_URL, {
        barbeiro,
        valor: Number(valorCorte),
        formaPagamento
      });
      fetchResumo();
      showToast(
        'sucesso',
        'Corte lançado com sucesso!',
        `${barbeiro} — R$ ${Number(valorCorte).toFixed(2).replace('.', ',')} via ${formaPagamento}`
      );
      setValorCorte(35);
      setFormaPagamento('Dinheiro');
    } catch (error) {
      showToast('erro', 'Erro ao lançar o corte.', 'Verifique a conexão e tente novamente.');
    } finally {
      setLancando(false);
    }
  };

  const abrirModalDeletar = (corte: any) => {
    setModal({ aberto: true, corteId: corte.id, barbeiro: corte.barbeiro, valor: corte.valor });
  };

  const confirmarDeletar = async () => {
    if (!modal.corteId) return;
    try {
      await axios.delete(`${API_URL}/${modal.corteId}`);
      fetchResumo();
      showToast('sucesso', 'Corte removido.', `Lançamento de ${modal.barbeiro} apagado.`);
    } catch (error) {
      showToast('erro', 'Erro ao apagar o corte.');
    } finally {
      setModal({ aberto: false, corteId: null, barbeiro: '', valor: 0 });
    }
  };

  if (loading && !resumo) return <div style={{ padding: '2rem' }}>Carregando dados da barbearia...</div>;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>

      {/* ── TOASTS ── */}
      <div style={{ position: 'fixed', top: '1.5rem', right: '1.5rem', zIndex: 9999, display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        {toasts.map(t => (
          <div
            key={t.id}
            style={{
              display: 'flex', alignItems: 'flex-start', gap: '0.75rem',
              padding: '1rem 1.25rem',
              borderRadius: '12px',
              boxShadow: '0 8px 30px rgba(0,0,0,0.15)',
              backgroundColor: t.tipo === 'sucesso' ? '#f0fdf4' : '#fef2f2',
              borderLeft: `4px solid ${t.tipo === 'sucesso' ? '#16a34a' : '#dc2626'}`,
              minWidth: '300px', maxWidth: '380px',
              animation: 'slideIn 0.3s ease',
            }}
          >
            {t.tipo === 'sucesso'
              ? <CheckCircle size={22} color="#16a34a" style={{ flexShrink: 0, marginTop: '2px' }} />
              : <AlertTriangle size={22} color="#dc2626" style={{ flexShrink: 0, marginTop: '2px' }} />
            }
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: '0.95rem', color: t.tipo === 'sucesso' ? '#15803d' : '#b91c1c' }}>
                {t.mensagem}
              </div>
              {t.sub && <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '0.2rem' }}>{t.sub}</div>}
            </div>
            <button
              onClick={() => setToasts(prev => prev.filter(x => x.id !== t.id))}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#94a3b8', padding: 0, flexShrink: 0 }}
            >
              <X size={16} />
            </button>
          </div>
        ))}
      </div>

      {/* ── MODAL CONFIRMAR EXCLUSÃO ── */}
      {modal.aberto && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 9998,
          backgroundColor: 'rgba(0,0,0,0.45)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          backdropFilter: 'blur(2px)',
          animation: 'fadeIn 0.2s ease',
        }}>
          <div style={{
            backgroundColor: 'white', borderRadius: '16px',
            padding: '2rem', width: '100%', maxWidth: '380px',
            boxShadow: '0 20px 60px rgba(0,0,0,0.25)',
            display: 'flex', flexDirection: 'column', gap: '1.25rem',
            animation: 'popIn 0.25s ease',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <div style={{ width: 44, height: 44, borderRadius: '50%', backgroundColor: '#fef2f2', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Trash2 size={22} color="#dc2626" />
              </div>
              <div>
                <div style={{ fontWeight: 700, fontSize: '1.1rem', color: '#1e293b' }}>Apagar lançamento?</div>
                <div style={{ fontSize: '0.85rem', color: '#64748b' }}>Esta ação não pode ser desfeita.</div>
              </div>
            </div>

            <div style={{ backgroundColor: '#f8fafc', borderRadius: '10px', padding: '0.85rem 1rem', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '0.8rem', color: '#64748b', marginBottom: '0.25rem' }}>Corte a ser removido</div>
              <div style={{ fontWeight: 700, color: '#1e293b' }}>
                {modal.barbeiro} — R$ {modal.valor?.toFixed(2).replace('.', ',')}
              </div>
            </div>

            <div style={{ display: 'flex', gap: '0.75rem' }}>
              <button
                onClick={() => setModal({ aberto: false, corteId: null, barbeiro: '', valor: 0 })}
                style={{
                  flex: 1, padding: '0.75rem', borderRadius: '8px',
                  border: '1.5px solid #e2e8f0', background: 'white',
                  fontWeight: 600, cursor: 'pointer', color: '#475569', fontSize: '0.9rem',
                }}
              >
                Cancelar
              </button>
              <button
                onClick={confirmarDeletar}
                style={{
                  flex: 1, padding: '0.75rem', borderRadius: '8px',
                  border: 'none', backgroundColor: '#dc2626',
                  fontWeight: 700, cursor: 'pointer', color: 'white', fontSize: '0.9rem',
                }}
              >
                Sim, apagar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── ANIMAÇÕES ── */}
      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateX(40px); }
          to   { opacity: 1; transform: translateX(0); }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to   { opacity: 1; }
        }
        @keyframes popIn {
          from { opacity: 0; transform: scale(0.92); }
          to   { opacity: 1; transform: scale(1); }
        }
      `}</style>

      {/* ── HEADER ── */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ margin: 0, color: 'var(--color-navy)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Scissors size={28} /> Barbearia
        </h1>
        <div style={{ color: 'var(--color-text-muted)', fontWeight: 500 }}>
          Controle de Cortes do Dia
        </div>
      </div>

      {/* ── CARDS DE RESUMO ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem' }}>
        <div className="card" style={{ padding: '1.5rem', borderTop: '4px solid var(--color-navy)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <User size={24} color="var(--color-navy)" />
              <h2 style={{ margin: 0, fontSize: '1.25rem', color: 'var(--color-navy)' }}>Jacson</h2>
            </div>
            <div style={{ padding: '0.25rem 0.75rem', backgroundColor: '#e2e8f0', borderRadius: '1rem', fontWeight: 'bold' }}>
              {resumo?.jacson.quantidade} cortes
            </div>
          </div>
          <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#2E7D32' }}>
            R$ {resumo?.jacson.total?.toFixed(2).replace('.', ',')}
          </div>
        </div>

        <div className="card" style={{ padding: '1.5rem', borderTop: '4px solid var(--color-red)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <User size={24} color="var(--color-red)" />
              <h2 style={{ margin: 0, fontSize: '1.25rem', color: 'var(--color-navy)' }}>Mizael</h2>
            </div>
            <div style={{ padding: '0.25rem 0.75rem', backgroundColor: '#e2e8f0', borderRadius: '1rem', fontWeight: 'bold' }}>
              {resumo?.mizael.quantidade} cortes
            </div>
          </div>
          <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#2E7D32' }}>
            R$ {resumo?.mizael.total?.toFixed(2).replace('.', ',')}
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
        {/* ── LANÇAR CORTE ── */}
        <div className="card" style={{ padding: '1.5rem' }}>
          <h2 style={{ margin: '0 0 1.5rem 0', fontSize: '1.25rem', color: 'var(--color-navy)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <DollarSign size={20} /> Lançar Novo Corte
          </h2>
          <form onSubmit={handleLancar} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500, fontSize: '0.875rem' }}>Selecione o Barbeiro</label>
              <div style={{ display: 'flex', gap: '1rem' }}>
                <button type="button" onClick={() => setBarbeiro('Jacson')}
                  style={{ flex: 1, padding: '1rem', border: '2px solid', borderColor: barbeiro === 'Jacson' ? 'var(--color-navy)' : 'var(--color-border)', backgroundColor: barbeiro === 'Jacson' ? '#f8fafc' : 'white', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '1.1rem' }}>
                  Jacson
                </button>
                <button type="button" onClick={() => setBarbeiro('Mizael')}
                  style={{ flex: 1, padding: '1rem', border: '2px solid', borderColor: barbeiro === 'Mizael' ? 'var(--color-red)' : 'var(--color-border)', backgroundColor: barbeiro === 'Mizael' ? '#fef2f2' : 'white', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '1.1rem' }}>
                  Mizael
                </button>
              </div>
            </div>

            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500, fontSize: '0.875rem' }}>Valor Cobrado (R$)</label>
              <input type="number" className="input" value={valorCorte}
                onChange={(e) => setValorCorte(e.target.value)}
                min="0" step="0.01" required
                style={{ fontSize: '1.25rem', padding: '0.75rem 1rem' }} />
            </div>

            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500, fontSize: '0.875rem' }}>Forma de Pagamento</label>
              <div style={{ display: 'flex', gap: '0.75rem' }}>
                <button type="button" onClick={() => setFormaPagamento('Dinheiro')}
                  style={{ flex: 1, padding: '0.75rem 0.5rem', border: '2px solid', borderColor: formaPagamento === 'Dinheiro' ? '#16a34a' : 'var(--color-border)', backgroundColor: formaPagamento === 'Dinheiro' ? '#f0fdf4' : 'white', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '0.85rem', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.25rem', color: formaPagamento === 'Dinheiro' ? '#16a34a' : 'var(--color-text-muted)' }}>
                  <Banknote size={20} /> Dinheiro
                </button>
                <button type="button" onClick={() => setFormaPagamento('Pix')}
                  style={{ flex: 1, padding: '0.75rem 0.5rem', border: '2px solid', borderColor: formaPagamento === 'Pix' ? '#7c3aed' : 'var(--color-border)', backgroundColor: formaPagamento === 'Pix' ? '#f5f3ff' : 'white', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '0.85rem', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.25rem', color: formaPagamento === 'Pix' ? '#7c3aed' : 'var(--color-text-muted)' }}>
                  <QrCode size={20} /> Pix
                </button>
                <button type="button" onClick={() => setFormaPagamento('Cartão')}
                  style={{ flex: 1, padding: '0.75rem 0.5rem', border: '2px solid', borderColor: formaPagamento === 'Cartão' ? '#0369a1' : 'var(--color-border)', backgroundColor: formaPagamento === 'Cartão' ? '#eff6ff' : 'white', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '0.85rem', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.25rem', color: formaPagamento === 'Cartão' ? '#0369a1' : 'var(--color-text-muted)' }}>
                  <CreditCard size={20} /> Cartão
                </button>
              </div>
            </div>

            <button type="submit" className="btn btn-primary" disabled={lancando}
              style={{ padding: '1rem', fontSize: '1.1rem', opacity: lancando ? 0.7 : 1 }}>
              {lancando ? 'Lançando...' : 'Confirmar Lançamento'}
            </button>
          </form>
        </div>

        {/* ── HISTÓRICO DO DIA ── */}
        <div className="card" style={{ padding: '0' }}>
          <div style={{ padding: '1.5rem', borderBottom: '1px solid var(--color-border)' }}>
            <h2 style={{ margin: 0, fontSize: '1.25rem', color: 'var(--color-navy)' }}>Últimos Lançamentos (Hoje)</h2>
          </div>
          <div style={{ overflowY: 'auto', maxHeight: '350px' }}>
            {resumo?.cortesDia && resumo.cortesDia.length > 0 ? (
              resumo.cortesDia.map((corte: any) => (
                <div key={corte.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1rem 1.5rem', borderBottom: '1px dotted var(--color-border)' }}>
                  <div style={{ display: 'flex', flexDirection: 'column' }}>
                    <span style={{ fontWeight: 'bold', fontSize: '1rem', color: corte.barbeiro === 'Jacson' ? 'var(--color-navy)' : 'var(--color-red)' }}>
                      {corte.barbeiro}
                    </span>
                    <span style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)' }}>
                      {new Date(corte.dataCorte + 'Z').toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <span style={{
                      fontSize: '0.75rem', fontWeight: 'bold', padding: '0.2rem 0.6rem',
                      borderRadius: '1rem',
                      backgroundColor: corte.formaPagamento === 'Pix' ? '#f5f3ff' : corte.formaPagamento === 'Cartão' ? '#eff6ff' : '#f0fdf4',
                      color: corte.formaPagamento === 'Pix' ? '#7c3aed' : corte.formaPagamento === 'Cartão' ? '#0369a1' : '#16a34a'
                    }}>
                      {corte.formaPagamento === 'Pix' ? '⬡ Pix' : corte.formaPagamento === 'Cartão' ? '🃏 Cartão' : '💵 Dinheiro'}
                    </span>
                    <span style={{ fontWeight: 'bold', fontSize: '1.1rem' }}>
                      R$ {corte.valor.toFixed(2).replace('.', ',')}
                    </span>
                    <button
                      onClick={() => abrirModalDeletar(corte)}
                      title="Apagar lançamento"
                      style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', padding: '0.25rem', borderRadius: '6px', display: 'flex', alignItems: 'center', transition: 'color 0.2s' }}
                      onMouseEnter={e => (e.currentTarget.style.color = '#dc2626')}
                      onMouseLeave={e => (e.currentTarget.style.color = '#94a3b8')}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--color-text-muted)' }}>Nenhum corte registrado hoje.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Barbearia;
