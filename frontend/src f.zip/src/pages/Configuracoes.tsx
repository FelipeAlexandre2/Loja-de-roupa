import React, { useState, useEffect } from 'react';
import { fetchWithAuth } from '../utils/fetchWithAuth';
import {
    Users, UserPlus, Trash2, KeyRound, ShieldCheck, ShieldAlert,
    X, Eye, EyeOff, Lock, RefreshCw, Crown, UserCog, Briefcase
} from 'lucide-react';

interface Usuario {
    id: number;
    login: string;
    role: string;
}

// Decodifica o payload do JWT sem biblioteca externa
function decodeJwtPayload(token: string): Record<string, any> | null {
    try {
        const base64 = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
        return JSON.parse(atob(base64));
    } catch {
        return null;
    }
}

function getCurrentUserInfo(): { login: string; role: string } {
    const token = localStorage.getItem('token');
    const login = localStorage.getItem('username') || 'Usuário';
    if (!token) return { login, role: 'USER' };
    const payload = decodeJwtPayload(token);
    // Spring Security coloca as roles em "roles" ou "authorities"
    const roles: string[] = payload?.roles || payload?.authorities || [];
    const role = roles.some((r: string) => r.includes('ADMIN')) ? 'ADMIN' : 'USER';
    return { login, role };
}

const ROLE_CONFIG: Record<string, { label: string; color: string; bg: string; border: string; Icon: any }> = {
    ADMIN: { label: 'Admin',    color: '#92400e', bg: '#fef3c7', border: '#fde68a', Icon: Crown      },
    USER:  { label: 'Usuário',  color: '#1e40af', bg: '#eff6ff', border: '#bfdbfe', Icon: ShieldAlert },
    CAIXA: { label: 'Caixa',   color: '#065f46', bg: '#d1fae5', border: '#6ee7b7', Icon: Briefcase  },
};

const RoleBadge: React.FC<{ role: string }> = ({ role }) => {
    const cfg = ROLE_CONFIG[role] || ROLE_CONFIG['USER'];
    return (
        <span style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.25rem',
            fontSize: '0.72rem', fontWeight: 700, padding: '0.2rem 0.6rem',
            borderRadius: '0.5rem',
            backgroundColor: cfg.bg, color: cfg.color,
            border: `1px solid ${cfg.border}`,
        }}>
            <cfg.Icon size={11} />
            {cfg.label}
        </span>
    );
};

const Configuracoes: React.FC = () => {
    const currentUser = getCurrentUserInfo();
    const isAdmin = currentUser.role === 'ADMIN';

    const [usuarios, setUsuarios] = useState<Usuario[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [successMsg, setSuccessMsg] = useState<string | null>(null);
    const [submitting, setSubmitting] = useState(false);

    // Modal Novo Usuário
    const [showModalNovo, setShowModalNovo] = useState(false);
    const [novoLogin, setNovoLogin] = useState('');
    const [novaSenha, setNovaSenha] = useState('');
    const [novoRole, setNovoRole] = useState<'ADMIN' | 'USER' | 'CAIXA'>('USER');
    const [showSenha, setShowSenha] = useState(false);

    // Modal Alterar Senha
    const [userParaAlterarSenha, setUserParaAlterarSenha] = useState<Usuario | null>(null);
    const [senhaAlteracao, setSenhaAlteracao] = useState('');
    const [showSenhaAlteracao, setShowSenhaAlteracao] = useState(false);

    // Alterando role
    const [alterandoRoleId, setAlterandoRoleId] = useState<number | null>(null);

    const showSuccess = (msg: string) => {
        setSuccessMsg(msg);
        setTimeout(() => setSuccessMsg(null), 3500);
    };

    const carregarUsuarios = async () => {
        try {
            setLoading(true);
            setError(null);
            const res = await fetchWithAuth(`${import.meta.env.VITE_API_URL}/api/usuarios`);
            if (!res.ok) throw new Error('Falha ao carregar usuários');
            setUsuarios(await res.json());
        } catch {
            setError('Não foi possível carregar os usuários.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { carregarUsuarios(); }, []);

    const handleCriarUsuario = async (e: React.FormEvent) => {
        e.preventDefault();
        if (novaSenha.length < 6) { alert('A senha deve ter pelo menos 6 caracteres.'); return; }
        try {
            setSubmitting(true);
            const res = await fetchWithAuth(`${import.meta.env.VITE_API_URL}/api/usuarios`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ login: novoLogin, senha: novaSenha, role: novoRole }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Erro ao criar usuário');
            setShowModalNovo(false);
            setNovoLogin(''); setNovaSenha(''); setNovoRole('USER'); setShowSenha(false);
            showSuccess(`Usuário "${novoLogin}" criado com sucesso!`);
            carregarUsuarios();
        } catch (err: any) {
            alert(err.message);
        } finally {
            setSubmitting(false);
        }
    };

    const handleExcluir = async (usuario: Usuario) => {
        if (!window.confirm(`Excluir o usuário "${usuario.login}"? Esta ação não pode ser desfeita.`)) return;
        try {
            const res = await fetchWithAuth(`${import.meta.env.VITE_API_URL}/api/usuarios/${usuario.id}`, { method: 'DELETE' });
            if (!res.ok) {
                const data = await res.json().catch(() => ({}));
                throw new Error(data.error || 'Erro ao excluir usuário.');
            }
            showSuccess(`Usuário "${usuario.login}" excluído.`);
            carregarUsuarios();
        } catch (err: any) {
            alert(err.message);
        }
    };

    const handleAlterarSenha = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!userParaAlterarSenha) return;
        if (senhaAlteracao.length < 6) { alert('A senha deve ter pelo menos 6 caracteres.'); return; }
        try {
            setSubmitting(true);
            const res = await fetchWithAuth(`${import.meta.env.VITE_API_URL}/api/usuarios/${userParaAlterarSenha.id}/senha`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ senha: senhaAlteracao }),
            });
            if (!res.ok) throw new Error('Erro ao alterar senha');
            setUserParaAlterarSenha(null);
            setSenhaAlteracao('');
            showSuccess('Senha alterada com sucesso!');
        } catch {
            alert('Erro ao alterar a senha.');
        } finally {
            setSubmitting(false);
        }
    };

    // Ciclo: USER → CAIXA → ADMIN → USER
    const proximoRole = (atual: string): string => {
        if (atual === 'USER')  return 'CAIXA';
        if (atual === 'CAIXA') return 'ADMIN';
        return 'USER';
    };
    const labelRole = (r: string) => r === 'ADMIN' ? 'Admin' : r === 'CAIXA' ? 'Caixa' : 'Usuário';

    const handleAlterarRole = async (usuario: Usuario) => {
        const novoRole = proximoRole(usuario.role);
        const acao = `alterar para ${labelRole(novoRole)}`;
        if (!window.confirm(`Deseja ${acao} o usuário "${usuario.login}"?`)) return;
        try {
            setAlterandoRoleId(usuario.id);
            const res = await fetchWithAuth(`${import.meta.env.VITE_API_URL}/api/usuarios/${usuario.id}/role`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ role: novoRole }),
            });
            const data = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(data.error || 'Erro ao alterar permissão.');
            showSuccess(`Permissão de "${usuario.login}" alterada para ${novoRole} com sucesso!`);
            carregarUsuarios();
        } catch (err: any) {
            alert(err.message);
        } finally {
            setAlterandoRoleId(null);
        }
    };

    // ─── Tela para usuários sem permissão ───
    if (!isAdmin) {
        return (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                <h1 style={{ margin: 0, color: 'var(--color-navy)', display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '1.75rem' }}>
                    <Users size={28} /> Configurações
                </h1>
                <div className="card" style={{ padding: '3rem', textAlign: 'center' }}>
                    <div style={{ marginBottom: '1rem', color: '#94a3b8' }}><Lock size={48} /></div>
                    <h2 style={{ margin: '0 0 0.5rem', color: 'var(--color-navy)' }}>Acesso Restrito</h2>
                    <p style={{ color: 'var(--color-text-muted)', margin: 0 }}>
                        Apenas administradores podem gerenciar usuários e permissões.
                    </p>
                    <div style={{ marginTop: '1.5rem', display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.6rem 1.2rem', backgroundColor: '#f1f5f9', borderRadius: '8px', color: '#64748b', fontSize: '0.9rem' }}>
                        <ShieldAlert size={16} />
                        Seu perfil: <strong>Usuário</strong>
                    </div>
                </div>
            </div>
        );
    }

    // ─── Tela Admin ───
    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>

            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h1 style={{ margin: 0, color: 'var(--color-navy)', display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '1.75rem' }}>
                    <Users size={28} /> Configurações
                </h1>
                <div style={{ display: 'flex', gap: '0.75rem' }}>
                    <button className="btn btn-outline" onClick={carregarUsuarios}
                        style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <RefreshCw size={16} /> Atualizar
                    </button>
                    <button className="btn btn-primary" onClick={() => setShowModalNovo(true)}
                        style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <UserPlus size={18} /> Novo Usuário
                    </button>
                </div>
            </div>

            {/* Feedback messages */}
            {successMsg && (
                <div style={{ backgroundColor: '#d1fae5', border: '1px solid #6ee7b7', color: '#065f46', padding: '0.75rem 1rem', borderRadius: '8px', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <ShieldCheck size={18} /> {successMsg}
                </div>
            )}
            {error && (
                <div style={{ backgroundColor: '#fee2e2', border: '1px solid #fca5a5', color: '#b91c1c', padding: '0.75rem 1rem', borderRadius: '8px' }}>
                    {error}
                </div>
            )}

            {/* Sessão atual */}
            <div className="card" style={{ padding: '1.5rem' }}>
                <h2 style={{ margin: '0 0 1rem 0', fontSize: '0.8rem', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
                    Sessão Atual
                </h2>
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div style={{
                        width: '52px', height: '52px', borderRadius: '50%',
                        background: 'linear-gradient(135deg, var(--color-navy), var(--color-red))',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        color: 'white', fontWeight: 'bold', fontSize: '1.3rem', flexShrink: 0
                    }}>
                        {currentUser.login.charAt(0).toUpperCase()}
                    </div>
                    <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 700, fontSize: '1.05rem' }}>{currentUser.login}</div>
                        <div style={{ marginTop: '0.3rem' }}><RoleBadge role={currentUser.role} /></div>
                    </div>
                    <button className="btn btn-outline"
                        style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}
                        onClick={() => {
                            const me = usuarios.find(u => u.login === currentUser.login);
                            if (me) { setUserParaAlterarSenha(me); setSenhaAlteracao(''); }
                            else { alert('Usuário não encontrado na lista.'); }
                        }}>
                        <KeyRound size={16} /> Alterar Minha Senha
                    </button>
                </div>
            </div>

            {/* Lista de usuários */}
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid var(--color-border)', display: 'flex', alignItems: 'center', gap: '0.75rem', backgroundColor: '#f8fafc' }}>
                    <UserCog size={20} color="var(--color-navy)" />
                    <h2 style={{ margin: 0, fontSize: '1rem', color: 'var(--color-navy)', fontWeight: 700 }}>
                        Gerenciamento de Usuários
                    </h2>
                    <span style={{ marginLeft: 'auto', backgroundColor: 'var(--color-navy)', color: 'white', padding: '0.2rem 0.75rem', borderRadius: '1rem', fontSize: '0.8rem', fontWeight: 700 }}>
                        {usuarios.length} {usuarios.length === 1 ? 'usuário' : 'usuários'}
                    </span>
                </div>

                {loading ? (
                    <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--color-text-muted)' }}>
                        Carregando...
                    </div>
                ) : usuarios.length === 0 ? (
                    <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--color-text-muted)' }}>
                        Nenhum usuário cadastrado.
                    </div>
                ) : (
                    <div>
                        {/* Cabeçalho da tabela */}
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 120px 1fr', padding: '0.6rem 1.5rem', backgroundColor: '#f1f5f9', borderBottom: '1px solid var(--color-border)', fontSize: '0.72rem', fontWeight: 700, textTransform: 'uppercase', color: '#94a3b8', letterSpacing: '0.06em' }}>
                            <span>Usuário</span>
                            <span>Permissão</span>
                            <span style={{ textAlign: 'right' }}>Ações</span>
                        </div>

                        {usuarios.map((u, i) => {
                            const isSelf = u.login === currentUser.login;
                            const isChangingRole = alterandoRoleId === u.id;
                            return (
                                <div key={u.id} style={{
                                    display: 'grid', gridTemplateColumns: '1fr 120px 1fr',
                                    alignItems: 'center', padding: '1rem 1.5rem',
                                    borderBottom: i < usuarios.length - 1 ? '1px solid var(--color-border)' : 'none',
                                    backgroundColor: isSelf ? '#f0f9ff' : 'white',
                                    transition: 'background 0.15s',
                                }}>
                                    {/* Info do usuário */}
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                                        <div style={{
                                            width: '38px', height: '38px', borderRadius: '50%', flexShrink: 0,
                                            background: u.role === 'ADMIN'
                                                ? 'linear-gradient(135deg, #1e3a5f, #b91c1c)'
                                                : 'linear-gradient(135deg, #cbd5e1, #94a3b8)',
                                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                                            color: 'white', fontWeight: 'bold', fontSize: '0.95rem'
                                        }}>
                                            {u.login.charAt(0).toUpperCase()}
                                        </div>
                                        <div>
                                            <div style={{ fontWeight: 600, fontSize: '0.95rem' }}>
                                                {u.login}
                                                {isSelf && <span style={{ marginLeft: '0.4rem', fontSize: '0.7rem', color: '#3b82f6', fontWeight: 700 }}>(você)</span>}
                                            </div>
                                            <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginTop: '0.1rem' }}>ID #{u.id}</div>
                                        </div>
                                    </div>

                                    {/* Badge de role */}
                                    <div><RoleBadge role={u.role} /></div>

                                    {/* Botões de ação */}
                                    <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
                                        {/* Alterar Role */}
                                        <button
                                            disabled={isSelf || isChangingRole}
                                            onClick={() => handleAlterarRole(u)}
                                            title={isSelf ? 'Não pode alterar seu próprio perfil' : `Alterar para ${labelRole(proximoRole(u.role))}`}
                                            style={{
                                                display: 'flex', alignItems: 'center', gap: '0.35rem',
                                                fontSize: '0.78rem', padding: '0.4rem 0.75rem',
                                                borderRadius: '6px', cursor: isSelf ? 'not-allowed' : 'pointer',
                                                border: `1px solid ${ROLE_CONFIG[u.role]?.border || '#bfdbfe'}`,
                                                backgroundColor: ROLE_CONFIG[u.role]?.bg || '#eff6ff',
                                                color: ROLE_CONFIG[u.role]?.color || '#1d4ed8',
                                                opacity: isSelf ? 0.4 : 1,
                                                transition: 'all 0.2s', fontWeight: 600,
                                            }}
                                            onMouseEnter={e => { if (!isSelf) e.currentTarget.style.filter = 'brightness(0.92)'; }}
                                            onMouseLeave={e => { e.currentTarget.style.filter = 'none'; }}
                                        >
                                            {isChangingRole ? (
                                                <RefreshCw size={13} style={{ animation: 'spin 1s linear infinite' }} />
                                            ) : (
                                                <ShieldCheck size={13} />
                                            )}
                                            → {labelRole(proximoRole(u.role))}
                                        </button>

                                        {/* Alterar senha */}
                                        <button className="btn btn-outline"
                                            style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.78rem', padding: '0.4rem 0.75rem' }}
                                            onClick={() => { setUserParaAlterarSenha(u); setSenhaAlteracao(''); setShowSenhaAlteracao(false); }}>
                                            <KeyRound size={13} /> Senha
                                        </button>

                                        {/* Excluir */}
                                        {!isSelf && (
                                            <button
                                                style={{
                                                    display: 'flex', alignItems: 'center', gap: '0.35rem',
                                                    fontSize: '0.78rem', padding: '0.4rem 0.75rem',
                                                    borderRadius: '6px', cursor: 'pointer',
                                                    border: '1px solid #fca5a5', background: 'transparent',
                                                    color: '#dc2626', transition: 'all 0.2s',
                                                }}
                                                onMouseEnter={e => { e.currentTarget.style.backgroundColor = '#fee2e2'; }}
                                                onMouseLeave={e => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                                                onClick={() => handleExcluir(u)}>
                                                <Trash2 size={13} /> Excluir
                                            </button>
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>

            {/* Guia de Permissões — 3 perfis */}
            <div className="card" style={{ padding: '1.25rem 1.5rem' }}>
                <h3 style={{ margin: '0 0 1rem', fontSize: '0.8rem', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
                    Guia de Permissões
                </h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem' }}>
                    {/* ADMIN */}
                    <div style={{ backgroundColor: '#fef9c3', border: '1px solid #fde68a', borderRadius: '8px', padding: '1rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem', fontWeight: 700, color: '#92400e' }}>
                            <Crown size={15} /> Administrador
                        </div>
                        <ul style={{ margin: 0, paddingLeft: '1.1rem', fontSize: '0.82rem', color: '#78350f', lineHeight: 1.8 }}>
                            <li>Dashboard</li>
                            <li>Frente de Caixa (PDV)</li>
                            <li>Caixa / Financeiro</li>
                            <li>Estoque</li>
                            <li>Barbearia</li>
                            <li><strong>Configurações</strong></li>
                        </ul>
                    </div>
                    {/* USER */}
                    <div style={{ backgroundColor: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: '8px', padding: '1rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem', fontWeight: 700, color: '#1e40af' }}>
                            <ShieldAlert size={15} /> Usuário
                        </div>
                        <ul style={{ margin: 0, paddingLeft: '1.1rem', fontSize: '0.82rem', color: '#1e3a8a', lineHeight: 1.8 }}>
                            <li>Dashboard</li>
                            <li>Frente de Caixa (PDV)</li>
                            <li>Caixa / Financeiro</li>
                            <li>Estoque</li>
                            <li>Barbearia</li>
                            <li style={{ color: '#94a3b8' }}>❌ Configurações</li>
                        </ul>
                    </div>
                    {/* CAIXA */}
                    <div style={{ backgroundColor: '#d1fae5', border: '1px solid #6ee7b7', borderRadius: '8px', padding: '1rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem', fontWeight: 700, color: '#065f46' }}>
                            <Briefcase size={15} /> Caixa
                        </div>
                        <ul style={{ margin: 0, paddingLeft: '1.1rem', fontSize: '0.82rem', color: '#065f46', lineHeight: 1.8 }}>
                            <li>Dashboard</li>
                            <li>Frente de Caixa (PDV)</li>
                            <li>Caixa / Financeiro</li>
                            <li>Estoque</li>
                            <li style={{ color: '#94a3b8' }}>❌ Barbearia</li>
                            <li style={{ color: '#94a3b8' }}>❌ Configurações</li>
                        </ul>
                    </div>
                </div>
            </div>

            {/* ── Modal: Novo Usuário ── */}
            {showModalNovo && (
                <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.55)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
                    <div className="card" style={{ width: '100%', maxWidth: '440px', padding: '2rem', animation: 'fadeInUp 0.25s ease-out' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.75rem' }}>
                            <h2 style={{ margin: 0, color: 'var(--color-navy)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                <UserPlus size={22} /> Novo Usuário
                            </h2>
                            <button onClick={() => setShowModalNovo(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--color-text-muted)' }}>
                                <X size={22} />
                            </button>
                        </div>
                        <form onSubmit={handleCriarUsuario} style={{ display: 'flex', flexDirection: 'column', gap: '1.1rem' }}>
                            <div>
                                <label className="form-label" style={{ display: 'block', marginBottom: '0.4rem', fontWeight: 600, fontSize: '0.85rem' }}>Login (usuário):</label>
                                <input className="input" type="text" value={novoLogin}
                                    onChange={e => setNovoLogin(e.target.value)}
                                    required placeholder="Ex: joao.silva" autoFocus />
                            </div>
                            <div>
                                <label className="form-label" style={{ display: 'block', marginBottom: '0.4rem', fontWeight: 600, fontSize: '0.85rem' }}>Senha:</label>
                                <div style={{ position: 'relative' }}>
                                    <input className="input" type={showSenha ? 'text' : 'password'}
                                        value={novaSenha} onChange={e => setNovaSenha(e.target.value)}
                                        required placeholder="Mínimo 6 caracteres" style={{ paddingRight: '2.75rem' }} />
                                    <button type="button" onClick={() => setShowSenha(s => !s)}
                                        style={{ position: 'absolute', right: '0.75rem', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--color-text-muted)' }}>
                                        {showSenha ? <EyeOff size={17} /> : <Eye size={17} />}
                                    </button>
                                </div>
                                {novaSenha.length > 0 && novaSenha.length < 6 && (
                                    <span style={{ fontSize: '0.75rem', color: '#dc2626', marginTop: '0.25rem', display: 'block' }}>
                                        Mínimo 6 caracteres ({novaSenha.length}/6)
                                    </span>
                                )}
                            </div>
                            <div>
                                <label className="form-label" style={{ display: 'block', marginBottom: '0.6rem', fontWeight: 600, fontSize: '0.85rem' }}>Perfil de Acesso:</label>
                                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.75rem' }}>
                                    {(['USER', 'CAIXA', 'ADMIN'] as const).map(r => {
                                        const cfg = ROLE_CONFIG[r];
                                        const selected = novoRole === r;
                                        return (
                                            <button key={r} type="button" onClick={() => setNovoRole(r)}
                                                style={{
                                                    padding: '0.85rem 0.5rem', border: '2px solid', borderRadius: '10px',
                                                    cursor: 'pointer', fontWeight: 700, transition: 'all 0.2s',
                                                    borderColor: selected ? cfg.color : 'var(--color-border)',
                                                    backgroundColor: selected ? cfg.bg : '#f8fafc',
                                                    color: selected ? cfg.color : 'var(--color-text)',
                                                    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.4rem',
                                                }}>
                                                <cfg.Icon size={20} />
                                                {cfg.label}
                                            </button>
                                        );
                                    })}
                                </div>
                                <p style={{ margin: '0.5rem 0 0', fontSize: '0.78rem', color: 'var(--color-text-muted)' }}>
                                    {novoRole === 'ADMIN'  ? '⚠️ Admin tem acesso total, incluindo configurações.' :
                                     novoRole === 'CAIXA'  ? '🏦 Caixa acessa PDV, Estoque, Dashboard e Caixa.' :
                                                             '👤 Usuário acessa tudo, exceto Configurações.'}
                                </p>
                            </div>
                            <div style={{ display: 'flex', gap: '0.75rem', marginTop: '0.5rem' }}>
                                <button type="button" className="btn btn-outline" onClick={() => setShowModalNovo(false)} style={{ flex: 1 }}>Cancelar</button>
                                <button type="submit" className="btn btn-primary" disabled={submitting} style={{ flex: 1 }}>
                                    {submitting ? 'Criando...' : 'Criar Usuário'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* ── Modal: Alterar Senha ── */}
            {userParaAlterarSenha && (
                <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.55)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
                    <div className="card" style={{ width: '100%', maxWidth: '390px', padding: '2rem', animation: 'fadeInUp 0.25s ease-out' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
                            <h2 style={{ margin: 0, color: 'var(--color-navy)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                <KeyRound size={20} /> Alterar Senha
                            </h2>
                            <button onClick={() => setUserParaAlterarSenha(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--color-text-muted)' }}>
                                <X size={22} />
                            </button>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '0.75rem', backgroundColor: '#f1f5f9', borderRadius: '8px', marginBottom: '1.25rem' }}>
                            <div style={{ width: '36px', height: '36px', borderRadius: '50%', background: 'var(--color-navy)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 700 }}>
                                {userParaAlterarSenha.login.charAt(0).toUpperCase()}
                            </div>
                            <div>
                                <div style={{ fontWeight: 600 }}>{userParaAlterarSenha.login}</div>
                                <RoleBadge role={userParaAlterarSenha.role} />
                            </div>
                        </div>
                        <form onSubmit={handleAlterarSenha} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                            <div style={{ position: 'relative' }}>
                                <input className="input" type={showSenhaAlteracao ? 'text' : 'password'}
                                    value={senhaAlteracao} onChange={e => setSenhaAlteracao(e.target.value)}
                                    required placeholder="Nova senha (mínimo 6 caracteres)" autoFocus style={{ paddingRight: '2.75rem' }} />
                                <button type="button" onClick={() => setShowSenhaAlteracao(s => !s)}
                                    style={{ position: 'absolute', right: '0.75rem', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--color-text-muted)' }}>
                                    {showSenhaAlteracao ? <EyeOff size={17} /> : <Eye size={17} />}
                                </button>
                            </div>
                            {senhaAlteracao.length > 0 && senhaAlteracao.length < 6 && (
                                <span style={{ fontSize: '0.75rem', color: '#dc2626' }}>
                                    Mínimo 6 caracteres ({senhaAlteracao.length}/6)
                                </span>
                            )}
                            <div style={{ display: 'flex', gap: '0.75rem' }}>
                                <button type="button" className="btn btn-outline" onClick={() => setUserParaAlterarSenha(null)} style={{ flex: 1 }}>Cancelar</button>
                                <button type="submit" className="btn btn-secondary" disabled={submitting} style={{ flex: 1 }}>
                                    {submitting ? 'Salvando...' : 'Confirmar'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            <style>{`
                @keyframes spin {
                    from { transform: rotate(0deg); }
                    to { transform: rotate(360deg); }
                }
            `}</style>
        </div>
    );
};

export default Configuracoes;
