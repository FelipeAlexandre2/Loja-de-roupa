import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';

import Dashboard from './pages/Dashboard';
import Estoque from './pages/Estoque';
import PDV from './pages/PDV';
import Barbearia from './pages/Barbearia';
import Caixa from './pages/Caixa';
import Login from './pages/Login';
import Configuracoes from './pages/Configuracoes';
import axios from 'axios';
import { Lock } from 'lucide-react';

// Interceptor global do Axios
axios.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// ── helpers ──────────────────────────────────────────────────────
function decodeJwt(token: string): Record<string, any> | null {
  try {
    return JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
  } catch { return null; }
}

function getRole(): string {
  const token = localStorage.getItem('token');
  if (!token) return '';
  const payload = decodeJwt(token);
  const roles: string[] = payload?.roles || payload?.authorities || [];
  if (roles.some((r: string) => r.includes('ADMIN'))) return 'ADMIN';
  if (roles.some((r: string) => r.includes('CAIXA'))) return 'CAIXA';
  return 'USER';
}

const PERMISSOES: Record<string, string[]> = {
  ADMIN:  ['/', '/pdv', '/caixa', '/estoque', '/barbearia', '/config'],
  USER:   ['/', '/pdv', '/caixa', '/estoque', '/barbearia'],
  CAIXA:  ['/', '/pdv', '/caixa', '/estoque'],
};

// ── Auth Guard ────────────────────────────────────────────────────
const AuthGuard = ({ children }: { children: React.ReactNode }) => {
  const token = localStorage.getItem('token');
  if (!token) return <Navigate to="/login" replace />;
  return <>{children}</>;
};

// ── Role Guard ────────────────────────────────────────────────────
const RoleGuard = ({ rota, children }: { rota: string; children: React.ReactNode }) => {
  const role = getRole();
  const permitido = PERMISSOES[role] || PERMISSOES['USER'];
  if (!permitido.includes(rota)) {
    return (
      <div style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        justifyContent: 'center', height: '60vh', gap: '1rem', color: '#94a3b8'
      }}>
        <Lock size={52} />
        <h2 style={{ margin: 0, color: '#1e293b' }}>Acesso Negado</h2>
        <p style={{ margin: 0, color: '#64748b', textAlign: 'center' }}>
          Seu perfil <strong>{role}</strong> não tem permissão para acessar esta página.
        </p>
      </div>
    );
  }
  return <>{children}</>;
};

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<AuthGuard><Layout /></AuthGuard>}>
          <Route index element={<RoleGuard rota="/"><Dashboard /></RoleGuard>} />
          <Route path="pdv"       element={<RoleGuard rota="/pdv"><PDV /></RoleGuard>} />
          <Route path="caixa"     element={<RoleGuard rota="/caixa"><Caixa /></RoleGuard>} />
          <Route path="estoque"   element={<RoleGuard rota="/estoque"><Estoque /></RoleGuard>} />
          <Route path="barbearia" element={<RoleGuard rota="/barbearia"><Barbearia /></RoleGuard>} />
          <Route path="config"    element={<RoleGuard rota="/config"><Configuracoes /></RoleGuard>} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
