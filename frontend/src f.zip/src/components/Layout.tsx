import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Store, ShoppingCart, Settings, Scissors, Wallet, LogOut, Crown, ShieldAlert, Briefcase } from 'lucide-react';

// ── helpers de role ──────────────────────────────────────────────
function decodeJwt(token: string): Record<string, any> | null {
  try {
    return JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
  } catch { return null; }
}

function getCurrentRole(): string {
  const token = localStorage.getItem('token');
  if (!token) return 'USER';
  const payload = decodeJwt(token);
  const roles: string[] = payload?.roles || payload?.authorities || [];
  if (roles.some((r: string) => r.includes('ADMIN'))) return 'ADMIN';
  if (roles.some((r: string) => r.includes('CAIXA'))) return 'CAIXA';
  return 'USER';
}

function getCurrentLogin(): string {
  return localStorage.getItem('username') || 'Usuário';
}

// ── Badge de role inline ─────────────────────────────────────────
const RolePill: React.FC<{ role: string }> = ({ role }) => {
  const map: Record<string, { label: string; color: string; bg: string; Icon: any }> = {
    ADMIN:  { label: 'Admin',    color: '#92400e', bg: '#fef3c7', Icon: Crown       },
    USER:   { label: 'Usuário',  color: '#1e40af', bg: '#eff6ff', Icon: ShieldAlert },
    CAIXA:  { label: 'Caixa',   color: '#065f46', bg: '#d1fae5', Icon: Briefcase   },
  };
  const cfg = map[role] || map['USER'];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: '0.2rem',
      fontSize: '0.65rem', fontWeight: 700, padding: '0.15rem 0.5rem',
      borderRadius: '0.5rem', backgroundColor: cfg.bg, color: cfg.color,
    }}>
      <cfg.Icon size={9} />
      {cfg.label}
    </span>
  );
};

// ── Permissões por role ──────────────────────────────────────────
const PERMISSOES: Record<string, string[]> = {
  ADMIN:  ['/', '/pdv', '/caixa', '/estoque', '/barbearia', '/config'],
  USER:   ['/', '/pdv', '/caixa', '/estoque', '/barbearia'],
  CAIXA:  ['/', '/pdv', '/caixa', '/estoque'],
};

const Layout: React.FC = () => {
  const role = getCurrentRole();
  const login = getCurrentLogin();
  const navigate = useNavigate();
  const permitido = PERMISSOES[role] || PERMISSOES['USER'];

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    navigate('/login');
  };

  const navItems = [
    { to: '/',           label: 'Dashboard',      Icon: LayoutDashboard, end: true  },
    { to: '/pdv',        label: 'Frente de Caixa', Icon: ShoppingCart,   end: false },
    { to: '/caixa',      label: 'Caixa',           Icon: Wallet,          end: false },
    { to: '/estoque',    label: 'Estoque',         Icon: Store,           end: false },
    { to: '/barbearia',  label: 'Barbearia',       Icon: Scissors,        end: false },
  ];

  return (
    <div className="app-layout">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-header">
          <img
            src="/logo.png"
            alt="Logo TT Loja"
            style={{ width: '40px', height: '40px', borderRadius: '50%', objectFit: 'cover' }}
          />
          <h2 style={{ margin: 0, fontSize: '1.25rem', letterSpacing: '1px' }}>LOJA</h2>
        </div>

        <nav className="sidebar-nav">
          {navItems
            .filter(item => permitido.includes(item.to))
            .map(({ to, label, Icon, end }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={({ isActive }) => isActive ? 'nav-item active' : 'nav-item'}
              >
                <Icon size={20} />
                {label}
              </NavLink>
            ))}

          <div style={{ flex: 1 }} />

          {/* Configurações — só ADMIN */}
          {permitido.includes('/config') && (
            <NavLink to="/config" className={({ isActive }) => isActive ? 'nav-item active' : 'nav-item'}>
              <Settings size={20} />
              Configurações
            </NavLink>
          )}
        </nav>

        {/* Usuário logado + logout */}
        <div style={{
          padding: '1rem',
          borderTop: '1px solid rgba(255,255,255,0.12)',
          display: 'flex', alignItems: 'center', gap: '0.65rem',
        }}>
          <div style={{
            width: '34px', height: '34px', borderRadius: '50%', flexShrink: 0,
            background: 'linear-gradient(135deg, var(--color-red), var(--color-navy))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: 'white', fontWeight: 'bold', fontSize: '0.9rem',
          }}>
            {login.charAt(0).toUpperCase()}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ color: 'white', fontWeight: 600, fontSize: '0.85rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {login}
            </div>
            <RolePill role={role} />
          </div>
          <button
            onClick={handleLogout}
            title="Sair"
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.55)', padding: '0.25rem', borderRadius: '6px', flexShrink: 0 }}
            onMouseEnter={e => (e.currentTarget.style.color = 'white')}
            onMouseLeave={e => (e.currentTarget.style.color = 'rgba(255,255,255,0.55)')}
          >
            <LogOut size={18} />
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="main-content">
        <header className="topbar">
          <div style={{ fontWeight: 500, color: 'var(--color-text-muted)' }}>
            {new Date().toLocaleDateString('pt-BR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{
              width: '36px', height: '36px',
              borderRadius: '50%', backgroundColor: 'var(--color-red)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'white', fontWeight: 'bold'
            }}>
              {login.charAt(0).toUpperCase()}
            </div>
            <div>
              <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{login}</div>
              <div style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)' }}>
                {role === 'ADMIN' ? 'Administrador' : role === 'CAIXA' ? 'Operador de Caixa' : 'Usuário'}
              </div>
            </div>
          </div>
        </header>

        <div className="page-content">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default Layout;
