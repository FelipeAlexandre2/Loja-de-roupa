package com.ttstore.backend.controller;

import com.ttstore.backend.model.VendaRequest;
import com.ttstore.backend.model.Venda;
import com.ttstore.backend.service.VendaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/vendas")
@CrossOrigin(origins = "*")
public class VendaController {

    private final VendaService vendaService;

    public VendaController(VendaService vendaService) {
        this.vendaService = vendaService;
    }

    @GetMapping
    public List<Venda> listarTodas() {
        return vendaService.listarTodas();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Venda> buscarPorId(@PathVariable Long id) {
        return vendaService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Venda realizarVenda(@RequestBody VendaRequest request) {
        return vendaService.realizarVenda(request.getItens(), request.getFormaPagamento());
    }

    @GetMapping("/resumo")
    public Map<String, Object> resumoDoDia() {
        return vendaService.buscarResumoDoDia();
    }
}
