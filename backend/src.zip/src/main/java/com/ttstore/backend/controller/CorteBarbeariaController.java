package com.ttstore.backend.controller;

import com.ttstore.backend.model.CorteBarbearia;
import com.ttstore.backend.service.CorteBarbeariaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/barbearia")
@CrossOrigin(origins = "*")
public class CorteBarbeariaController {

    private final CorteBarbeariaService service;

    public CorteBarbeariaController(CorteBarbeariaService service) {
        this.service = service;
    }

    @GetMapping("/resumo")
    public Map<String, Object> resumoDoDia() {
        return service.buscarResumoDoDia();
    }

    @PostMapping
    public ResponseEntity<CorteBarbearia> registrarNovoCorte(@RequestBody CorteBarbearia corte) {
        CorteBarbearia salvo = service.registrarCorte(corte);
        return ResponseEntity.ok(salvo);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluirCorte(@PathVariable Long id) {
        service.excluirCorte(id);
        return ResponseEntity.noContent().build();
    }
}
