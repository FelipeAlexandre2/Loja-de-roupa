package com.ttstore.backend.controller;

import com.ttstore.backend.model.MovimentacaoCaixa;
import com.ttstore.backend.service.MovimentacaoCaixaService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/caixamovimento")
@CrossOrigin(origins = "*")
public class MovimentacaoCaixaController {
    private final MovimentacaoCaixaService service;

    public MovimentacaoCaixaController(MovimentacaoCaixaService service) {
        this.service = service;
    }

    @PostMapping
    public MovimentacaoCaixa registrar(@RequestBody MovimentacaoCaixa mov) {
        return service.registrar(mov);
    }

    @GetMapping("/resumo")
    public Map<String, Object> resumoDoDia() {
        return service.buscarResumoDoDia();
    }
}
