package com.ttstore.backend.controller;

import com.ttstore.backend.model.Usuario;
import com.ttstore.backend.repository.UsuarioRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = "*")
public class UsuarioController {

    private final UsuarioRepository repository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioController(UsuarioRepository repository, PasswordEncoder passwordEncoder) {
        this.repository = repository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping
    public List<Map<String, Object>> listarTodos() {
        return repository.findAll().stream().map(u -> Map.<String, Object>of(
            "id", u.getId(),
            "login", u.getLogin(),
            "role", u.getRole()
        )).collect(Collectors.toList());
    }

    @PostMapping
    public ResponseEntity<?> criar(@RequestBody Map<String, String> dados) {
        String login = dados.get("login");
        String senha = dados.get("senha");
        String role = dados.getOrDefault("role", "USER");

        if (login == null || login.isBlank() || senha == null || senha.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Login e senha são obrigatórios."));
        }
        if (senha.length() < 6) {
            return ResponseEntity.badRequest().body(Map.of("error", "A senha deve ter pelo menos 6 caracteres."));
        }
        if (repository.findByLogin(login).isPresent()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Usuário já existe."));
        }

        Usuario novo = new Usuario(login, passwordEncoder.encode(senha), role.toUpperCase());
        repository.save(novo);
        return ResponseEntity.ok(Map.of("message", "Usuário criado com sucesso.", "login", login));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> excluir(@PathVariable Long id) {
        return repository.findById(id).map(u -> {
            // Impede excluir o único admin
            if ("ADMIN".equals(u.getRole())) {
                long adminCount = repository.findAll().stream()
                    .filter(a -> "ADMIN".equals(a.getRole())).count();
                if (adminCount <= 1) {
                    return ResponseEntity.badRequest().body(
                        Map.<String, Object>of("error", "Não é possível excluir o único administrador do sistema.")
                    );
                }
            }
            repository.deleteById(id);
            return ResponseEntity.noContent().<Map<String, Object>>build();
        }).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/senha")
    public ResponseEntity<?> alterarSenha(@PathVariable Long id, @RequestBody Map<String, String> dados) {
        return repository.findById(id).map(u -> {
            String novaSenha = dados.get("senha");
            if (novaSenha == null || novaSenha.isBlank()) {
                return ResponseEntity.badRequest().body(Map.<String, Object>of("error", "Senha inválida."));
            }
            if (novaSenha.length() < 6) {
                return ResponseEntity.badRequest().body(Map.<String, Object>of("error", "A senha deve ter pelo menos 6 caracteres."));
            }
            u.setSenha(passwordEncoder.encode(novaSenha));
            repository.save(u);
            return ResponseEntity.ok(Map.<String, Object>of("message", "Senha alterada com sucesso."));
        }).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/role")
    public ResponseEntity<?> alterarRole(@PathVariable Long id, @RequestBody Map<String, String> dados) {
        String novoRole = dados.get("role");
        if (novoRole == null || novoRole.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "O campo 'role' é obrigatório."));
        }
        if (!novoRole.equalsIgnoreCase("ADMIN") && !novoRole.equalsIgnoreCase("USER") && !novoRole.equalsIgnoreCase("CAIXA")) {
            return ResponseEntity.badRequest().body(Map.of("error", "Role inválido. Use ADMIN, USER ou CAIXA."));
        }

        return repository.findById(id).map(u -> {
            // Impede rebaixar o único admin
            if ("ADMIN".equals(u.getRole()) && "USER".equalsIgnoreCase(novoRole)) {
                long adminCount = repository.findAll().stream()
                    .filter(a -> "ADMIN".equals(a.getRole())).count();
                if (adminCount <= 1) {
                    return ResponseEntity.badRequest().body(
                        Map.<String, Object>of("error", "Não é possível rebaixar o único administrador do sistema.")
                    );
                }
            }
            u.setRole(novoRole.toUpperCase());
            repository.save(u);
            return ResponseEntity.ok(Map.<String, Object>of(
                "message", "Permissão alterada com sucesso.",
                "login", u.getLogin(),
                "role", u.getRole()
            ));
        }).orElse(ResponseEntity.notFound().build());
    }
}
