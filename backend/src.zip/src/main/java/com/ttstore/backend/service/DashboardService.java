package com.ttstore.backend.service;

import com.ttstore.backend.model.ItemVenda;
import com.ttstore.backend.model.Produto;
import com.ttstore.backend.model.Venda;
import com.ttstore.backend.repository.ProdutoRepository;
import com.ttstore.backend.repository.VendaRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DashboardService {

    private final VendaRepository vendaRepository;
    private final ProdutoRepository produtoRepository;

    public DashboardService(VendaRepository vendaRepository, ProdutoRepository produtoRepository) {
        this.vendaRepository = vendaRepository;
        this.produtoRepository = produtoRepository;
    }

    public Map<String, Object> getDashboardResumo() {
        // 1. Total de Vendas Hoje
        LocalDateTime inicioDoDia = LocalDateTime.now().toLocalDate().atStartOfDay();
        LocalDateTime fimDoDia = LocalDateTime.now().toLocalDate().atTime(LocalTime.MAX);
        List<Venda> vendasHoje = vendaRepository.findByDataHoraBetween(inicioDoDia, fimDoDia);

        BigDecimal totalRSHoje = BigDecimal.ZERO;
        for (Venda v : vendasHoje) {
            if (v.getTotal() != null) {
                totalRSHoje = totalRSHoje.add(v.getTotal());
            }
        }

        // 2. Vendas dos Ultimos 30 Dias e 3. Produto Mais Vendido
        LocalDateTime trintaDiasAtras = LocalDateTime.now().minusDays(30);
        List<Venda> vendas30Dias = vendaRepository.findByDataHoraAfter(trintaDiasAtras);

        BigDecimal totalRS30Dias = BigDecimal.ZERO;
        Map<Produto, Integer> produtosAgrupados = new HashMap<>();

        for (Venda v : vendas30Dias) {
            if (v.getTotal() != null) {
                totalRS30Dias = totalRS30Dias.add(v.getTotal());
            }
            if (v.getItens() != null) {
                for (ItemVenda item : v.getItens()) {
                    Produto p = item.getProduto();
                    if (p != null) {
                        produtosAgrupados.put(p, produtosAgrupados.getOrDefault(p, 0) + item.getQuantidade());
                    }
                }
            }
        }

        String produtoMaisVendidoNome = "Nenhum";
        int maxVendas = 0;
        for (Map.Entry<Produto, Integer> entry : produtosAgrupados.entrySet()) {
            if (entry.getValue() > maxVendas && entry.getKey() != null && entry.getKey().getNome() != null) {
                maxVendas = entry.getValue();
                produtoMaisVendidoNome = entry.getKey().getNome() + " (" + maxVendas + " un)";
            }
        }

        // 4. Peças físicamente cadastradas no estoque
        List<Produto> todosProdutos = produtoRepository.findAll();
        int totalPecasEstoque = 0;
        for (Produto p : todosProdutos) {
            if (p.getQuantidadeEstoque() != null) {
                totalPecasEstoque += p.getQuantidadeEstoque();
            }
        }

        Map<String, Object> resumo = new HashMap<>();
        resumo.put("vendasHoje", totalRSHoje);
        resumo.put("vendas30Dias", totalRS30Dias);
        resumo.put("produtoMaisVendido", produtoMaisVendidoNome);
        resumo.put("totalPecasEstoque", totalPecasEstoque);
        return resumo;
    }
}
